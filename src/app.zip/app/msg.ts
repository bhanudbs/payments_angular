export class msg1{
    msg:string
    instruction:string
    constructor(msg: string,instruction:string){
        this.msg=msg
        this.instruction=instruction
    }
}