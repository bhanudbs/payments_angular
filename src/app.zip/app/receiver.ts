export class Receiver{
    constructor(public bic:string, public name:string){}
}