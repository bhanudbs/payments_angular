export class Sender{
    constructor(cust_id:number, name:string, balance:number, overdraft:string){}
}