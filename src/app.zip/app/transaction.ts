export class Transaction{
    
    constructor(public receiver_name: String, public s_id: number,public r_id: number,public b_id:String, public amount: number,public msg: string,public transaction_status: string)
    {
        
    }

}